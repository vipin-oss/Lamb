# Paper A (Sumit): Guided Lamb waves in a piezoelectric semiconductor plate
MGT thermal + linearised carriers + nonlocal strain gradient (2 length scales).

**Hook (to confirm in week 9):** where attenuation peaks vs carrier density and frequency-thickness, and how the two length scales move/suppress that peak.
**Base paper available after Step 4.**

## Tracker
| Step | What | Check | Scholar | Arena cross-check |
|---|---|---|---|---|
| 1 | Elastic Rayleigh-Lamb | see common/step1_instructions.md | [ ] | [ ] |
| 2 | + piezoelectric (open/short) | coupling off -> Step 1; K^2 from open/short | [ ] | [ ] |
| 3 | + MGT heat | thermal off -> Step 2; classical thermoelastic limit | [ ] | [ ] |
| 4 | + carriers | n0 -> 0 returns Step 3; high-n0 limit sane | [ ] | [ ] |
| 5 | + NSGT | l = 0 returns Step 4; nonlocal-only, gradient-only checked | [ ] | [ ] |
| 6 | Analysis, figures | smooth branches, consistent root counts | [ ] | [ ] |

## To fix before Step 2
- Polarisation (poling) direction: along thickness z (decide and write it here).
- Material: ZnO or GaAs? Choose one primary; list constants + source in `params.md`.
- DC doping/bias assumed for the linearised carrier equation; state validity regime.

## Folder layout
`steps/` equations per step - `checks/` comparison files - `code_arena/` - `figures/` - `paper/`
