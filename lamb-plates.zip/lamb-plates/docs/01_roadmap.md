# Roadmap (14 weeks to submission-ready draft per paper)

Staggered so you are never reviewing three Step-N plots in the same week.
Sumit leads, Neha one week behind, Anu two weeks behind.

| Week | Sumit (semiconductor) | Neha (quasicrystal) | Anu (MEE) | You / Arena |
|---|---|---|---|---|
| 1 | Literature + novelty sweep, Step 1 equations | Reading items 1-5, decide poling/quasi axis | Reading items 1-3, fix poling axis | Run common solver, send equations pack |
| 2 | Step 1 done -> plot | Step 1 | Reading, Step 1 | Cross-check Step 1 numbers (3 scholars) |
| 3 | Step 2 piezo | Step 1 done / Step 2 | Step 1 | Independent Step 2 in Arena for Sumit |
| 4 | Step 3 MGT heat | Step 2 | Step 2 | Cross-check Sumit; start Neha Step 2 check |
| 5 | Step 4 carriers | Step 3 phason (decision gate) | Step 2 done / Step 3 | Arena: carrier limit check |
| 6 | Step 4 done, **base paper figures** | Step 3 done | Step 3 | Cross-check Neha Step 3 vs published |
| 7 | Step 5 NSGT | Step 4 MGT | Step 3 done | Arena NSGT root-count check |
| 8 | Step 5 | Step 4 done | Step 4 MGT | |
| 9 | Step 6 analysis | Step 5 NSGT | Step 4 done | Hook decision for each paper |
| 10 | Figures + writing | Step 5 | Step 5 | |
| 11 | Draft complete | Step 6 | Step 5 | |
| 12 | Internal review | Figures + writing | Step 6 | |
| 13 | Revise, journal choice | Draft | Figures + writing | |
| 14 | **Submit paper A** | Revise | Draft | |
(Neha and Anu submit about weeks 16-18.)

## Gates (stop and decide)
- **Week 2:** novelty sweep for all three. If a near-identical paper exists, change the hook now.
- **Step 3 of Neha:** phason wave-like vs diffusive. Pick, justify, test the other.
- **Step 4 of Sumit:** carriers-off returns Step 3 AND high-density limit sane. This is a base paper.
- **Before any NSGT step:** fix the extra boundary conditions in writing (see equations pack).
- **Week 9:** for each paper write the one-sentence finding (the hook). No sentence -> reduce target journal.

## Weekly rhythm
1. Monday: scholar sends check plot + one-page note of what changed.
2. Tuesday: you (with Arena) run the same step independently; compare using `docs/02_workflow_crosscheck.md`.
3. Wednesday: feedback + next-step equations to scholar.
4. Rest of week: scholar works; you and Arena only prepare the *next* step.

## Deliverables in the repo as work progresses
`semiconductor_sumit/`, `quasicrystal_neha/`, `mee_anu/` each contain:
`README.md` (status tracker), `steps/stepN_*.md` (equations + instruction for the scholar),
`checks/` (verification results), `code_arena/` (your independent implementation),
`figures/`, `paper/`.
